
function debuggerHalter()
{
	debugger;
}
