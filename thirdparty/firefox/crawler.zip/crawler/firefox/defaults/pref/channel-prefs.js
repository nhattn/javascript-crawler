//@line 2 "e:\builds\moz2_slave\win32_build\build\browser\app\profile\channel-prefs.js"
pref("app.update.channel", "release");
