// ==UserScript==
// @name           User script template
// @namespace      http://mywebsite.com/myscripts
// @description    A template for creating new user scripts from
// @include        *
// ==/UserScript==
