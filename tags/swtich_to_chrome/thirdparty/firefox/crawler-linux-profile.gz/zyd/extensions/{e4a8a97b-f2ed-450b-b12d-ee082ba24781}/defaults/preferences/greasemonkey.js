pref("extensions.{e4a8a97b-f2ed-450b-b12d-ee082ba24781}.description", "chrome://greasemonkey/locale/greasemonkey.properties");
pref("greasemonkey.aboutIsGreaseable", false);
pref("greasemonkey.fileIsGreaseable", false);
pref("greasemonkey.unmhtIsGreaseable", false);
